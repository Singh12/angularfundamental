import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { map, catchError } from 'rxjs/operators';
import { RecipeServiceService } from '../recipes/service/recipe-service.service';
import { Recipe } from '../recipes/recipe.model';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AuthServices } from '../auth/auth.service';
@Injectable()
export class DataStorageService {
constructor(private http: Http, private recipeService: RecipeServiceService, private authToken: AuthServices) { }
// function to save data

saveRecipe() {
    const token = this.authToken.getAuthToken();
    return this.http.put('https://recipe-4fc9a.firebaseio.com/recipe.json?auth=' + token, this.recipeService.getRecipe());
}
getRecipe() {
   console.log(this.authToken.getAuthToken());
    const token = this.authToken.getAuthToken();
this.http.get('https://recipe-4fc9a.firebaseio.com/recipe.json?auth=' + token)
        .pipe(map((response: Response) => {
            const recipes: Recipe[] = response.json();
            recipes.forEach(recipe => {
                if (!recipe['ingredients']) {
                    recipe['ingredients'] = [];
                }
            });
           return recipes;
        })).subscribe(
            (recipes: Recipe[]) => {
                console.log(recipes);
                this.recipeService.setRecipe(recipes);
            }
        );
}
}
