import { NgModule } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { RecipesComponent } from './recipes/recipes.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { RecipeStartComponent } from './recipes/recipe-start/recipe-start.component';
import { RecipeEditComponent } from './recipes/recipe-edit/recipe-edit.component';
import { EditObserverComponent } from './edit-observer/edit-observer.component';
import { HomeComponent } from './edit-observer/home/home.component';
import { UsersComponent } from './edit-observer/users/users.component';
import { LearningFormComponent } from './learning-form/learning-form.component';
import { LearningReactiveFormComponent } from './learning-reactive-form/learning-reactive-form.component';
import { PipeComponent } from './pipes/pipe/pipe.component';
import { ServerComponent } from './httprequest/server/server.component';
import { SignupComponent } from './auth/signup/signup.component';
import { SigninComponent } from './auth/signin/signin.component';
import { RouteGardService } from './auth/routegard.service';
const recipeRoute: Routes = [
    {path: '', redirectTo: '/recipes', pathMatch: 'full'},
    {path: 'recipes', component: RecipesComponent, children: [
        { path: '', component: RecipeStartComponent },
        { path: 'new', component: RecipeEditComponent, canActivate: [RouteGardService]},
        {path: ':id', component: RecipeDetailComponent},
        { path: ':id/edit', component: RecipeEditComponent, canActivate: [RouteGardService]}
    ] },
    { path: 'shopping-list', component: ShoppingListComponent },
    { path: 'observer', component: EditObserverComponent, children: [
        { path: '', redirectTo: 'home', pathMatch: 'full' },
        { path: 'home', component: HomeComponent },
        { path: 'user/:id', component: UsersComponent }
    ] },
     { path: 'formdata', component: LearningFormComponent },
    { path: 'pipes', component: PipeComponent },
    { path: 'serverhttp', component: ServerComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'signin', component: SigninComponent },
    { path: 'reactive', component: LearningReactiveFormComponent }
];
@NgModule({
imports: [RouterModule.forRoot(recipeRoute)],
exports: [RouterModule]

})
export class AppRoute {}
