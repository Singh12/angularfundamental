import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-observer',
  templateUrl: './edit-observer.component.html',
  styleUrls: ['./edit-observer.component.css']
})
export class EditObserverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
