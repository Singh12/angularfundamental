import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RecipesComponent } from './recipes/recipes.component';
import { RecipeListComponent } from './recipes/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { RecipeItemComponent } from './recipes/recipe-list/recipe-item/recipe-item.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
import { ShoppingEditComponent } from './shopping-list/shopping-edit/shopping-edit.component';
import { Recipe } from './recipes/recipe.model';
import { MenustyleDecoretorDirective } from './decoretor/menustyle-decoretor.directive';
import { RecipeShoppingServiceService } from './shopping-list/service/recipe-shopping-service.service';
import { AppRoute } from './app.route.module';
import { RecipeStartComponent } from './recipes/recipe-start/recipe-start.component';
import { RecipeEditComponent } from './recipes/recipe-edit/recipe-edit.component';
import { EditObserverComponent } from './edit-observer/edit-observer.component';
import { HomeComponent } from './edit-observer/home/home.component';
import { UsersComponent } from './edit-observer/users/users.component';
import { LearningFormComponent } from './learning-form/learning-form.component';
import { LearningReactiveFormComponent } from './learning-reactive-form/learning-reactive-form.component';
import { RecipeServiceService } from './recipes/service/recipe-service.service';
import { PipeComponent } from './pipes/pipe/pipe.component';
import { Shoretn } from './pipes/pipe/shorten';
import { Filter } from './pipes/pipe/filter';
import { ServerComponent } from './httprequest/server/server.component';
import { ServiceService } from './httprequest/service.service';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { environment } from '../environments/environment';
import { DataStorageService } from './shared/data-storage.service';
import { SignupComponent } from './auth/signup/signup.component';
import { SigninComponent } from './auth/signin/signin.component';
import { AuthServices } from './auth/auth.service';
import { RouteGardService } from './auth/routegard.service';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RecipesComponent,
    RecipeListComponent,
    RecipeDetailComponent,
    RecipeItemComponent,
    ShoppingListComponent,
    ShoppingEditComponent,
    MenustyleDecoretorDirective,
    RecipeStartComponent,
    RecipeEditComponent,
    EditObserverComponent,
    HomeComponent,
    UsersComponent,
    LearningFormComponent,
    LearningReactiveFormComponent,
    PipeComponent,
    Shoretn,
    Filter,
    ServerComponent,
    SignupComponent,
    SigninComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoute,
    HttpModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule
  ],
  // providers: [RecipeShoppingServiceService, AuthService, AuthGard, CanDeactivateGard, ServerResolver, ServerServiceService],
  providers: [RecipeShoppingServiceService, RecipeServiceService, ServiceService, DataStorageService, AuthServices, RouteGardService],

  bootstrap: [AppComponent]
})
export class AppModule { }
